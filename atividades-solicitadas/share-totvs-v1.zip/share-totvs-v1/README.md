# share

Arquivos e materiais compartilhados.

## Conteúdo

- [`totvs-protheus/`](totvs-protheus/) — guia de instalação do Protheus 8 (Jornada DEV START).
  O instalador (`TOTVS.zip`) está disponível em [Releases](../../releases/latest).
