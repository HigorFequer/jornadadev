# Instalação do Protheus — Jornada DEV START

Guia rápido para colocar o **Protheus 8** funcionando na sua máquina Windows. O objetivo aqui
**não é entender a arquitetura ou administrar o sistema** — é só deixar tudo pronto para você
**usar** o Protheus nas próximas aulas.

> 💻 **Requisito:** Windows (o Protheus SmartClient não roda no macOS/Linux nativamente).
> ⏱️ **Tempo estimado:** 10–15 minutos.

---

## 1. Baixe o pacote

Baixe o arquivo `TOTVS.zip` na página de [Releases deste repositório](../../releases/latest) e
salve-o diretamente em `C:\`.

![Arquivo TOTVS.zip baixado em C:\](assets/01-arquivo-baixado.png)

---

## 2. Extraia o pacote

Clique com o **botão direito** sobre `TOTVS.zip` e escolha **Extrair Tudo...**

![Menu de contexto — Extrair Tudo](assets/02-extrair-tudo.png)

Confirme o destino como `C:\` (já vem selecionado por padrão) e clique em **Extrair**.

![Diálogo de extração com destino C:\](assets/03-destino-extracao.png)

---

## 3. Confira a pasta extraída

Depois da extração, você terá uma pasta `C:\TOTVS` com os atalhos principais:

![Pasta C:\TOTVS com atalhos Protheus, DevStudio, Server e Smartclient](assets/04-pasta-extraida.png)

O que você vai usar no dia a dia:
- **Smartclient** → é o programa que você vai abrir para acessar o sistema
- **Server** → inicia o servidor do Protheus (se ainda não estiver rodando)
- **DevStudio** → ambiente de desenvolvimento (usaremos mais adiante no curso)

---

## 4. Abra o Smartclient

Dê duplo clique no atalho **Smartclient**. Na tela de parâmetros iniciais, confirme os valores
abaixo (geralmente já vêm preenchidos) e clique em **Ok**:

| Campo | Valor |
|---|---|
| Programa inicial | `SIGAMDI` |
| Comunicação no cliente | `TCP` |
| Ambiente no servidor | `Environment` |

![Tela de parâmetros iniciais do Protheus](assets/05-parametros-iniciais.png)

---

## 5. Faça login

Na tela de boas-vindas, use o usuário abaixo (sem senha) e clique em **Entrar**:

| Campo | Valor |
|---|---|
| Usuário | `Administrador` |
| Senha | *(deixe em branco)* |

![Tela de login do Protheus](assets/06-tela-login.png)

---

## 6. Escolha empresa e ambiente

Selecione a Empresa/Filial **Teste / Matriz** e o Ambiente **Faturamento**, depois clique em
**Confirmar**.

![Tela de seleção de empresa e ambiente](assets/07-empresa-ambiente.png)

Pronto! 🎉 O Protheus está aberto e você já pode acompanhar as próximas aulas.

---

## Problemas comuns

- **Antivírus bloqueando a extração ou execução:** libere a pasta `C:\TOTVS` como exceção no
  antivírus do Windows.
- **Nada abre ao clicar em Smartclient:** confirme que extraiu o ZIP inteiro em `C:\` (não em
  `Downloads` ou em outra pasta) — os atalhos apontam para esse caminho.
- **Erro de conexão ao abrir o Smartclient:** dê um tempo (10–20s) após extrair antes de abrir —
  o servidor incluso no pacote precisa iniciar primeiro.

Dúvidas? Chama no Discord da turma, canal `#duvidas-parte2-protheus`. 🤝
